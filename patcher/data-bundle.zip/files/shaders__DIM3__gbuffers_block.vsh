#version 430 compatibility

#define WORLD
#define BLOCKENTITIES

#define OVERWORLD_SHADER

#define PLANET_MOON

#include "/dimensions/all_solid.vsh"
