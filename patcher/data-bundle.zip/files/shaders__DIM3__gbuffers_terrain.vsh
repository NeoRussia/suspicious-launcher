#version 430 compatibility

#define OVERWORLD_SHADER

#define PLANET_MOON

#define WORLD

#include "/dimensions/all_solid.vsh"
